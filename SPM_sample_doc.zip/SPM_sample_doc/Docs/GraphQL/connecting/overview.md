# Overview of the GraphQL queries

The main objective of the GraphQL query documentation is to familiarize you with how to construct and send GraphQL queries for your GraphQL APIs.
