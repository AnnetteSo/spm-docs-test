# Building your GraphQL APIs

The GraphQL Server and GraphQL APIs are incorporated into the REST application.
Different build targets are used depedning on if you are building the REST application with GraphQL APIs for your local Tomcat environment or a deployed application server.
