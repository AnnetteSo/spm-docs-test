# Testing a GraphQL query using Postman

TODO - add details of how to call/integrate with a GraphQL query.

One endpoint only, which is a POST request.

All details specifiying which query to invoke, which attributes are being requested in the resposne, and any input params are all send in the JSON body.

Add examples.

How to authenticate and send the token as a cookie (for deployed applications only, not needed for Tomcat).
Set the referer header.
(Details of these are the same as for REST APIs).

Describe how the GraphiQL UI tool can be used to try out a query, and the JSON body could be copied from this, using the Network tab. (The GraphiQL UI is only built into the dev app, it is not included in the ear).

(Note: Any other helpful tips on how to construct the JSON request body? How did the front-end devs figure this out in the CaseOverview project, when calling the ootb queries?)
